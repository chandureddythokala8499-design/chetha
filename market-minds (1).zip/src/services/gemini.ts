import { GoogleGenAI, Type } from "@google/genai";
import { UserPreferences, MarketContext, MarketAnalysis } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function generateMarketRecommendations(
  preferences: UserPreferences,
  context: MarketContext
): Promise<MarketAnalysis> {
  const prompt = `
    As a professional market analyst, provide personalized market recommendations and analysis.
    
    User Preferences:
    - Sectors of Interest: ${preferences.sectors.join(", ")}
    - Risk Tolerance: ${preferences.riskTolerance}
    - Investment Goal: ${preferences.investmentGoal}
    - Time Horizon: ${preferences.timeHorizon}
    
    Market Context/Topic: ${context.topic}
    Additional Info: ${context.additionalInfo || "None provided"}
    
    Provide a comprehensive analysis including specific recommendations, overall market sentiment, and top trends.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          recommendations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                summary: { type: Type.STRING },
                rationale: { type: Type.STRING },
                riskLevel: { type: Type.STRING, enum: ["low", "medium", "high"] },
                potentialImpact: { type: Type.STRING },
                actionableSteps: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING }
                }
              },
              required: ["title", "summary", "rationale", "riskLevel", "potentialImpact", "actionableSteps"]
            }
          },
          marketSentiment: { type: Type.STRING, enum: ["bullish", "bearish", "neutral"] },
          topTrends: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["recommendations", "marketSentiment", "topTrends"]
      }
    }
  });

  return JSON.parse(response.text || "{}") as MarketAnalysis;
}
