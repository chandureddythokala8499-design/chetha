import React from 'react';
import { Brain, TrendingUp, Shield, BarChart3 } from 'lucide-react';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-black/5 bg-white/80 backdrop-blur-md">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-lg shadow-emerald-200">
            <Brain size={24} />
          </div>
          <span className="text-xl font-bold tracking-tight text-slate-900">
            Market<span className="text-emerald-600">Minds</span>
          </span>
        </div>
        
        <nav className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
          <a href="#" className="hover:text-emerald-600 transition-colors">Dashboard</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Insights</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Portfolio</a>
          <a href="#" className="hover:text-emerald-600 transition-colors">Settings</a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="rounded-full bg-slate-900 px-5 py-2 text-sm font-medium text-white hover:bg-slate-800 transition-all shadow-md">
            Get Started
          </button>
        </div>
      </div>
    </header>
  );
}
