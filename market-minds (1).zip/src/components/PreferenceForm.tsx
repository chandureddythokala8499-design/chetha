import React, { useState } from 'react';
import { UserPreferences, RiskTolerance } from '../types';
import { Shield, Target, Clock, LayoutGrid, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';

interface PreferenceFormProps {
  onSubmit: (prefs: UserPreferences) => void;
  isLoading: boolean;
}

export function PreferenceForm({ onSubmit, isLoading }: PreferenceFormProps) {
  const [prefs, setPrefs] = useState<UserPreferences>({
    sectors: [],
    riskTolerance: 'medium',
    investmentGoal: '',
    timeHorizon: '',
  });

  const sectors = [
    'Technology', 'Healthcare', 'Energy', 'Finance', 
    'Consumer Goods', 'Real Estate', 'AI & Robotics', 'Green Energy'
  ];

  const toggleSector = (sector: string) => {
    setPrefs(prev => ({
      ...prev,
      sectors: prev.sectors.includes(sector)
        ? prev.sectors.filter(s => s !== sector)
        : [...prev.sectors, sector]
    }));
  };

  return (
    <div className="space-y-8 rounded-3xl bg-white p-8 shadow-xl shadow-slate-200/50 border border-slate-100">
      <div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Configure Your Profile</h2>
        <p className="text-slate-500">Tell us about your investment style for personalized insights.</p>
      </div>

      <div className="space-y-6">
        {/* Sectors */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <LayoutGrid size={18} className="text-emerald-600" />
            Sectors of Interest
          </label>
          <div className="flex flex-wrap gap-2">
            {sectors.map(sector => (
              <button
                key={sector}
                onClick={() => toggleSector(sector)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-all border",
                  prefs.sectors.includes(sector)
                    ? "bg-emerald-50 border-emerald-200 text-emerald-700 shadow-sm"
                    : "bg-white border-slate-200 text-slate-600 hover:border-emerald-200"
                )}
              >
                {sector}
              </button>
            ))}
          </div>
        </div>

        {/* Risk Tolerance */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Shield size={18} className="text-emerald-600" />
            Risk Tolerance
          </label>
          <div className="grid grid-cols-3 gap-3">
            {(['low', 'medium', 'high'] as RiskTolerance[]).map(risk => (
              <button
                key={risk}
                onClick={() => setPrefs({ ...prefs, riskTolerance: risk })}
                className={cn(
                  "px-4 py-3 rounded-xl text-sm font-medium transition-all border capitalize text-center",
                  prefs.riskTolerance === risk
                    ? "bg-emerald-600 border-emerald-600 text-white shadow-lg shadow-emerald-100"
                    : "bg-white border-slate-200 text-slate-600 hover:border-emerald-200"
                )}
              >
                {risk}
              </button>
            ))}
          </div>
        </div>

        {/* Investment Goal */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Target size={18} className="text-emerald-600" />
            Primary Investment Goal
          </label>
          <input
            type="text"
            placeholder="e.g., Retirement, Wealth Growth, Passive Income"
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            value={prefs.investmentGoal}
            onChange={e => setPrefs({ ...prefs, investmentGoal: e.target.value })}
          />
        </div>

        {/* Time Horizon */}
        <div className="space-y-3">
          <label className="flex items-center gap-2 text-sm font-semibold text-slate-700">
            <Clock size={18} className="text-emerald-600" />
            Time Horizon
          </label>
          <select
            className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-white"
            value={prefs.timeHorizon}
            onChange={e => setPrefs({ ...prefs, timeHorizon: e.target.value })}
          >
            <option value="">Select a timeframe</option>
            <option value="1-3 years">Short term (1-3 years)</option>
            <option value="3-7 years">Medium term (3-7 years)</option>
            <option value="7+ years">Long term (7+ years)</option>
          </select>
        </div>
      </div>

      <button
        onClick={() => onSubmit(prefs)}
        disabled={isLoading || !prefs.investmentGoal || !prefs.timeHorizon || prefs.sectors.length === 0}
        className="w-full flex items-center justify-center gap-2 bg-emerald-600 text-white py-4 rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg shadow-emerald-100"
      >
        {isLoading ? (
          <div className="h-5 w-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
        ) : (
          <>
            Generate Market Insights
            <ChevronRight size={20} />
          </>
        )}
      </button>
    </div>
  );
}
