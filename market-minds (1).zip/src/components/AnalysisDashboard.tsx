import React from 'react';
import { MarketAnalysis, Recommendation } from '../types';
import { TrendingUp, TrendingDown, Minus, AlertTriangle, CheckCircle2, ArrowUpRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

interface AnalysisDashboardProps {
  analysis: MarketAnalysis;
}

export function AnalysisDashboard({ analysis }: AnalysisDashboardProps) {
  const sentimentIcons = {
    bullish: <TrendingUp className="text-emerald-600" size={32} />,
    bearish: <TrendingDown className="text-rose-600" size={32} />,
    neutral: <Minus className="text-slate-400" size={32} />,
  };

  const riskColors = {
    low: 'bg-emerald-100 text-emerald-700',
    medium: 'bg-amber-100 text-amber-700',
    high: 'bg-rose-100 text-rose-700',
  };

  return (
    <div className="space-y-8">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex items-center gap-4"
        >
          <div className="p-4 bg-slate-50 rounded-2xl">
            {sentimentIcons[analysis.marketSentiment]}
          </div>
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Market Sentiment</p>
            <p className="text-xl font-bold text-slate-900 capitalize">{analysis.marketSentiment}</p>
          </div>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 md:col-span-2"
        >
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={18} className="text-emerald-600" />
            <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Emerging Trends</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {analysis.topTrends.map((trend, i) => (
              <span key={i} className="px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-sm font-medium border border-emerald-100">
                {trend}
              </span>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Recommendations */}
      <div className="space-y-6">
        <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <ArrowUpRight size={24} className="text-emerald-600" />
          Strategic Recommendations
        </h3>
        
        <div className="grid grid-cols-1 gap-6">
          {analysis.recommendations.map((rec, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 + 0.2 }}
              className="group bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:shadow-slate-200/50 transition-all"
            >
              <div className="flex flex-col md:flex-row justify-between gap-4 mb-6">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h4 className="text-2xl font-bold text-slate-900">{rec.title}</h4>
                    <span className={cn("px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider", riskColors[rec.riskLevel])}>
                      {rec.riskLevel} Risk
                    </span>
                  </div>
                  <p className="text-slate-600 leading-relaxed max-w-3xl">{rec.summary}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Potential Impact</p>
                  <p className="text-lg font-bold text-emerald-600">{rec.potentialImpact}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 pt-6 border-t border-slate-50">
                <div>
                  <h5 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <AlertTriangle size={16} className="text-amber-500" />
                    Strategic Rationale
                  </h5>
                  <p className="text-sm text-slate-500 leading-relaxed italic">
                    "{rec.rationale}"
                  </p>
                </div>
                <div>
                  <h5 className="text-sm font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-500" />
                    Actionable Steps
                  </h5>
                  <ul className="space-y-3">
                    {rec.actionableSteps.map((step, j) => (
                      <li key={j} className="flex items-start gap-3 text-sm text-slate-600">
                        <div className="mt-1 h-1.5 w-1.5 rounded-full bg-emerald-400 shrink-0" />
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
