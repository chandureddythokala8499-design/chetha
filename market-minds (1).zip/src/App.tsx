import React, { useState } from 'react';
import { Header } from './components/Header';
import { PreferenceForm } from './components/PreferenceForm';
import { AnalysisDashboard } from './components/AnalysisDashboard';
import { UserPreferences, MarketAnalysis, MarketContext } from './types';
import { generateMarketRecommendations } from './services/gemini';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, Search, Info, TrendingUp, BarChart3, Globe, Shield, Brain } from 'lucide-react';

export default function App() {
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<MarketAnalysis | null>(null);
  const [marketContext, setMarketContext] = useState<MarketContext>({
    topic: 'Current global market trends and opportunities',
    additionalInfo: ''
  });

  const handleGenerate = async (prefs: UserPreferences) => {
    setIsLoading(true);
    try {
      const result = await generateMarketRecommendations(prefs, marketContext);
      setAnalysis(result);
    } catch (error) {
      console.error('Failed to generate analysis:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f8f9fa] selection:bg-emerald-100 selection:text-emerald-900">
      <Header />
      
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto space-y-16">
          
          {/* Hero Section */}
          <section className="text-center space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-50 text-emerald-700 text-sm font-bold border border-emerald-100"
            >
              <Sparkles size={16} />
              AI-Powered Market Intelligence
            </motion.div>
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-5xl md:text-7xl font-bold text-slate-900 tracking-tight"
            >
              Your Personal <br />
              <span className="text-emerald-600 italic font-serif">Market Mind</span>
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="text-xl text-slate-500 max-w-2xl mx-auto leading-relaxed"
            >
              Harness the power of Generative AI to receive personalized investment insights, 
              trend analysis, and strategic recommendations tailored to your unique profile.
            </motion.p>
          </section>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left Column: Inputs */}
            <div className="lg:col-span-5 space-y-8">
              <PreferenceForm onSubmit={handleGenerate} isLoading={isLoading} />
              
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 space-y-4">
                <div className="flex items-center gap-2 text-sm font-bold text-slate-900">
                  <Globe size={18} className="text-emerald-600" />
                  Market Focus
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Analysis Topic</label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                      <input 
                        type="text"
                        value={marketContext.topic}
                        onChange={(e) => setMarketContext({ ...marketContext, topic: e.target.value })}
                        className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                        placeholder="e.g., Tech stocks in 2024"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">Context / News (Optional)</label>
                    <textarea 
                      value={marketContext.additionalInfo}
                      onChange={(e) => setMarketContext({ ...marketContext, additionalInfo: e.target.value })}
                      className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 min-h-[100px]"
                      placeholder="Paste recent news or specific concerns here..."
                    />
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-2xl border border-amber-100">
                <Info size={20} className="text-amber-600 shrink-0 mt-0.5" />
                <p className="text-xs text-amber-800 leading-relaxed">
                  <strong>Disclaimer:</strong> Market Minds provides AI-generated insights for informational purposes only. 
                  Always consult with a certified financial advisor before making investment decisions.
                </p>
              </div>
            </div>

            {/* Right Column: Results */}
            <div className="lg:col-span-7">
              <AnimatePresence mode="wait">
                {analysis ? (
                  <motion.div
                    key="results"
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                  >
                    <AnalysisDashboard analysis={analysis} />
                  </motion.div>
                ) : (
                  <motion.div
                    key="placeholder"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="h-full min-h-[600px] flex flex-col items-center justify-center text-center p-12 bg-white rounded-[40px] border-2 border-dashed border-slate-200"
                  >
                    <div className="relative mb-8">
                      <div className="absolute inset-0 bg-emerald-500 blur-3xl opacity-10 animate-pulse" />
                      <div className="relative h-24 w-24 bg-slate-50 rounded-3xl flex items-center justify-center text-slate-300">
                        <BarChart3 size={48} />
                      </div>
                    </div>
                    <h3 className="text-2xl font-bold text-slate-900 mb-3">Ready for Analysis</h3>
                    <p className="text-slate-500 max-w-sm">
                      Complete your profile and specify a market focus to generate your personalized intelligence report.
                    </p>
                    
                    <div className="mt-12 grid grid-cols-2 gap-4 w-full max-w-md">
                      <div className="p-4 bg-slate-50 rounded-2xl text-left">
                        <TrendingUp size={20} className="text-emerald-600 mb-2" />
                        <p className="text-xs font-bold text-slate-900 uppercase tracking-wider">Trend Detection</p>
                        <p className="text-[10px] text-slate-500">Real-time pattern recognition across sectors.</p>
                      </div>
                      <div className="p-4 bg-slate-50 rounded-2xl text-left">
                        <Shield size={20} className="text-emerald-600 mb-2" />
                        <p className="text-xs font-bold text-slate-900 uppercase tracking-wider">Risk Assessment</p>
                        <p className="text-[10px] text-slate-500">Personalized risk-reward modeling.</p>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-slate-100 bg-white py-12 mt-24">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4 opacity-50">
            <Brain size={20} />
            <span className="text-sm font-bold tracking-tight text-slate-900 uppercase">
              MarketMinds
            </span>
          </div>
          <p className="text-sm text-slate-400">
            © 2024 Market Minds AI. Empowering investors through intelligence.
          </p>
        </div>
      </footer>
    </div>
  );
}
