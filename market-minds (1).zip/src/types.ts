export type RiskTolerance = 'low' | 'medium' | 'high';

export interface UserPreferences {
  sectors: string[];
  riskTolerance: RiskTolerance;
  investmentGoal: string;
  timeHorizon: string;
}

export interface MarketContext {
  topic: string;
  additionalInfo?: string;
}

export interface Recommendation {
  title: string;
  summary: string;
  rationale: string;
  riskLevel: RiskTolerance;
  potentialImpact: string;
  actionableSteps: string[];
}

export interface MarketAnalysis {
  recommendations: Recommendation[];
  marketSentiment: 'bullish' | 'bearish' | 'neutral';
  topTrends: string[];
}
